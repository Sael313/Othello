public class OthelloPlayer {
    String name;
    public OthelloPlayer(String name) {
        this.name = name;
    }
    public void setName(String u){
        this.name = u;
    }
    public String getName(){
        return this.name;
    }
}

