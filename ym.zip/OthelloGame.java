public class OthelloGame {
    OthelloPlayer player1,player2;
    OthelloBoard Na;
    static int sag = -1;
    int npo;
    boolean p1;
    boolean p2;
    boolean payan = false;
    public OthelloGame(OthelloPlayer player1, OthelloPlayer player2, int n) {
        this.player1 = player1;
        this.player2 = player2;
        p1 = true;
        p2 = true;
        this.npo = n;
        this.Na = new OthelloBoard(n);
    }

    public boolean Valid(boolean blackPlayer){
        for(int i1 = 0;i1 < this.npo;i1++){
            for(int i2 = 0;i2 < this.npo;i2++){
                if(Na.A[Na.dor][i1][i2] == null){
                    if(isvalidMove(blackPlayer,i1,i2)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    public boolean isvalidMove(boolean blackPlayer, int i, int j) {
            if (Na.A[Na.dor][i][j] == null) {
                if (j <= npo - 3) {    //         rast
                    if (Na.A[Na.dor][i][j + 1] != null) {
                        if (Na.A[Na.dor][i][j + 1].isBlack() != blackPlayer) {
                            for (int i1 = j + 1; i1 < npo; i1++) {
                                if (Na.A[Na.dor][i][i1] == null) {
                                    break;
                                }

                                if (Na.A[Na.dor][i][i1].isBlack() == blackPlayer) {
                                    return true;
                                }

                            }
                        }
                    }
                }
                if (j >= 2) {     // chap
                    if (Na.A[Na.dor][i][j - 1] != null) {
                        if (Na.A[Na.dor][i][j - 1].isBlack() != blackPlayer) {
                            for (int i1 = j - 1; i1 >= 0; i1--) {
                                if (Na.A[Na.dor][i][i1] == null) {
                                    break;
                                }

                                if (Na.A[Na.dor][i][i1].isBlack() == blackPlayer) {
                                    return true;
                                }

                            }
                        }
                    }
                }
                if (i <= npo - 3) { // paeen
                    if (Na.A[Na.dor][i + 1][j] != null) {
                        if (Na.A[Na.dor][i + 1][j].isBlack() != blackPlayer) {
                            for (int i1 = i + 1; i1 < npo; i1++) {
                                if (Na.A[Na.dor][i1][j] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][i1][j].isBlack() == blackPlayer) {
                                    return true;
                                }
                            }
                        }
                    }
                }
                if (i >= 2) {  // bala
                    if (Na.A[Na.dor][i - 1][j] != null) {
                        if (Na.A[Na.dor][i - 1][j].isBlack() != blackPlayer) {
                            for (int i1 = i - 1; i1 >= 0; i1--) {
                                if (Na.A[Na.dor][i1][j] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][i1][j].isBlack() == blackPlayer) {
                                    return true;
                                }
                            }
                        }
                    }
                }
                if (j <= npo - 3 && i >= 2) { // bala_rast
                    if (Na.A[Na.dor][i - 1][j + 1] != null) {
                        if (Na.A[Na.dor][i - 1][j + 1].isBlack() != blackPlayer) {
                            int y1 = i - 1, y2 = j + 1;
                            for (int i1 = Math.min(i - 1, npo - 1 - j - 1); i1 >= 0; i1--) {
                                if (Na.A[Na.dor][y1][y2] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                    return true;
                                }
                                y1--;
                                y2++;
                            }
                        }
                    }
                }
                if (i >= 2 && j >= 2) {  // bala_chap
                    if (Na.A[Na.dor][i - 1][j - 1] != null) {
                        if (Na.A[Na.dor][i - 1][j - 1].isBlack() != blackPlayer) {
                            int y1 = i - 1, y2 = j - 1;
                            for (int i1 = Math.min(y1, y2); i1 >= 0; i1--) {
                                if (Na.A[Na.dor][y1][y2] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                    return true;
                                }
                                y1--;
                                y2--;
                            }
                        }
                    }
                }
                if (i <= npo - 3 && j <= npo - 3) {  // paeen_rast
                    if (Na.A[Na.dor][i + 1][j + 1] != null) {
                        if (Na.A[Na.dor][i + 1][j + 1].isBlack() != blackPlayer) {
                            int y1 = i + 1, y2 = j + 1;
                            for (int i1 = Math.min(npo - 1 - y1, npo - 1 - y2); i1 >= 0; i1--) {
                                if (Na.A[Na.dor][y1][y2] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                    return true;
                                }
                                y1++;
                                y2++;
                            }
                        }
                    }
                }
                if (i <= npo - 3 && j >= 2) {  // paeen_chap
                    if (Na.A[Na.dor][i + 1][j - 1] != null) {
                        if (Na.A[Na.dor][i + 1][j - 1].isBlack() != blackPlayer) {
                            int y1 = i + 1, y2 = j - 1;
                            for (int i1 = Math.min(y2, npo - 1 - y1); i1 >= 0; i1--) {
                                if (Na.A[Na.dor][y1][y2] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                    return true;
                                }
                                y1++;
                                y2--;
                            }
                        }
                    }
                }


        }
        return false;
    }
    public boolean isValidMove(boolean blackPlayer, int i, int j) {
        if(Na.isBlackPlayerToMove() == blackPlayer && (payan==false))
        {
            if (Na.A[Na.dor][i][j] == null) {
                if (j <= npo - 3) {    //         rast
                    if (Na.A[Na.dor][i][j + 1] != null) {
                        if (Na.A[Na.dor][i][j + 1].isBlack() != blackPlayer) {
                            for (int i1 = j + 1; i1 < npo; i1++) {
                                if (Na.A[Na.dor][i][i1] == null) {
                                    break;
                                }

                                if (Na.A[Na.dor][i][i1].isBlack() == blackPlayer) {
                                    return true;
                                }

                            }
                        }
                    }
                }
                if (j >= 2) {     // chap
                    if (Na.A[Na.dor][i][j - 1] != null) {
                        if (Na.A[Na.dor][i][j - 1].isBlack() != blackPlayer) {
                            for (int i1 = j - 1; i1 >= 0; i1--) {
                                if (Na.A[Na.dor][i][i1] == null) {
                                    break;
                                }

                                if (Na.A[Na.dor][i][i1].isBlack() == blackPlayer) {
                                    return true;
                                }

                            }
                        }
                    }
                }
                if (i <= npo - 3) { // paeen
                    if (Na.A[Na.dor][i + 1][j] != null) {
                        if (Na.A[Na.dor][i + 1][j].isBlack() != blackPlayer) {
                            for (int i1 = i + 1; i1 < npo; i1++) {
                                if (Na.A[Na.dor][i1][j] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][i1][j].isBlack() == blackPlayer) {
                                    return true;
                                }
                            }
                        }
                    }
                }
                if (i >= 2) {  // bala
                    if (Na.A[Na.dor][i - 1][j] != null) {
                        if (Na.A[Na.dor][i - 1][j].isBlack() != blackPlayer) {
                            for (int i1 = i - 1; i1 >= 0; i1--) {
                                if (Na.A[Na.dor][i1][j] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][i1][j].isBlack() == blackPlayer) {
                                    return true;
                                }
                            }
                        }
                    }
                }
                if (j <= npo - 3 && i >= 2) { // bala_rast
                    if (Na.A[Na.dor][i - 1][j + 1] != null) {
                        if (Na.A[Na.dor][i - 1][j + 1].isBlack() != blackPlayer) {
                            int y1 = i - 1, y2 = j + 1;
                            for (int i1 = Math.min(i - 1, npo - 1 - j - 1); i1 >= 0; i1--) {
                                if (Na.A[Na.dor][y1][y2] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                    return true;
                                }
                                y1--;
                                y2++;
                            }
                        }
                    }
                }
                if (i >= 2 && j >= 2) {  // bala_chap
                    if (Na.A[Na.dor][i - 1][j - 1] != null) {
                        if (Na.A[Na.dor][i - 1][j - 1].isBlack() != blackPlayer) {
                            int y1 = i - 1, y2 = j - 1;
                            for (int i1 = Math.min(y1, y2); i1 >= 0; i1--) {
                                if (Na.A[Na.dor][y1][y2] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                    return true;
                                }
                                y1--;
                                y2--;
                            }
                        }
                    }
                }
                if (i <= npo - 3 && j <= npo - 3) {  // paeen_rast
                    if (Na.A[Na.dor][i + 1][j + 1] != null) {
                        if (Na.A[Na.dor][i + 1][j + 1].isBlack() != blackPlayer) {
                            int y1 = i + 1, y2 = j + 1;
                            for (int i1 = Math.min(npo - 1 - y1, npo - 1 - y2); i1 >= 0; i1--) {
                                if (Na.A[Na.dor][y1][y2] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                    return true;
                                }
                                y1++;
                                y2++;
                            }
                        }
                    }
                }
                if (i <= npo - 3 && j >= 2) {  // paeen_chap
                    if (Na.A[Na.dor][i + 1][j - 1] != null) {
                        if (Na.A[Na.dor][i + 1][j - 1].isBlack() != blackPlayer) {
                            int y1 = i + 1, y2 = j - 1;
                            for (int i1 = Math.min(y2, npo - 1 - y1); i1 >= 0; i1--) {
                                if (Na.A[Na.dor][y1][y2] == null) {
                                    break;
                                }
                                if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                    return true;
                                }
                                y1++;
                                y2--;
                            }
                        }
                    }
                }

            }
        }
        return false;
    }

    public void movePlayer(boolean blackPlayer, int i, int j) {
        sag += 1;
        //k+=1; -------------------------------------------------------Should be checkeed!!!!!!!111
        Na.Y[sag] = blackPlayer;
        if(isValidMove(blackPlayer,i,j) == true) {
            for(int i1 = 0;i1 < Na.c;i1++){
                for(int i2 = 0;i2 < Na.c;i2++){
                    if(Na.A[Na.dor][i1][i2] != null){
                        Na.A[Na.dor+1][i1][i2] = new OthelloDisk(true);
                        Na.A[Na.dor+1][i1][i2].setR(Na.A[Na.dor][i1][i2].isBlack());
                    }
                }
            }
            Na.dor ++;
            if (j <= npo - 3) {    //         rast
                if(Na.A[Na.dor][i][j + 1] != null) {
                    if (Na.A[Na.dor][i][j + 1].isBlack() != blackPlayer) {
                        int u = -1;
                        boolean e2 = true;
                        for (int i1 = j + 1; i1 < npo; i1++) {
                            if(Na.A[Na.dor][i][i1] == null){
                                e2 = false;
                                break;
                            }
                            if (Na.A[Na.dor][i][i1].isBlack() == blackPlayer) {
                                u = i1;
                                break;
                            }
                        }
                        if(e2) {
                            for (int i1 = j + 1; i1 <= u; i1++) {
                                Na.A[Na.dor][i][i1].setR(blackPlayer);
                            }
                        }
                    }
                }

            } if (j >= 2) {     // chap
                if(Na.A[Na.dor][i][j - 1] != null) {
                    if (Na.A[Na.dor][i][j - 1].isBlack() != blackPlayer) {
                        int u = 10000;
                        boolean e2 = true;
                        for (int i1 = j - 1; i1 >= 0; i1--) {
                            if (Na.A[Na.dor][i][i1] == null) {
                                e2 = false;
                                break;
                            }
                            if (Na.A[Na.dor][i][i1].isBlack() == blackPlayer) {
                                u = i1;
                                break;
                            }
                        }
                        if(e2) {
                            for (int i1 = u; i1 <= j - 1; i1++) {
                                Na.A[Na.dor][i][i1].setR(blackPlayer);
                            }
                        }
                    }
                }
            } if (i <= npo - 3) { // paeen
                if(Na.A[Na.dor][i + 1][j] != null) {
                    if (Na.A[Na.dor][i + 1][j].isBlack() != blackPlayer) {
                        int u = -1;
                        boolean e2 = true;
                        for (int i1 = i + 1; i1 < npo; i1++) {
                            if(Na.A[Na.dor][i1][j] == null){
                                e2 = false;
                                break;
                            }
                            if (Na.A[Na.dor][i1][j].isBlack() == blackPlayer) {
                                u = i1;
                                break;
                            }
                        }
                        if(e2) {
                            for (int i1 = i + 1; i1 <= u; i1++) {
                                Na.A[Na.dor][i1][j].setR(blackPlayer);
                            }
                        }
                    }
                }
            } if (i >= 2) {  // bala
                if(Na.A[Na.dor][i - 1][j] != null) {
                    if (Na.A[Na.dor][i - 1][j].isBlack() != blackPlayer) {
                        int u = 100000;
                        boolean e2 = true;
                        for (int i1 = i - 1; i1 >= 0; i1--) {
                            if(Na.A[Na.dor][i1][j] == null){
                                e2 = false;
                                break;
                            }
                            if (Na.A[Na.dor][i1][j].isBlack() == blackPlayer) {
                                u = i1;
                                break;
                            }
                        }
                        if(e2) {
                            for (int i1 = u; i1 <= i - 1; i1++) {
                                Na.A[Na.dor][i1][j].setR(blackPlayer);
                            }
                        }
                    }
                }







            } if (j <= npo - 3 && i >= 2) { // bala_rast
                if(Na.A[Na.dor][i - 1][j + 1] != null) {
                    if (Na.A[Na.dor][i - 1][j + 1].isBlack() != blackPlayer) {
                        int y1 = i - 1, y2 = j + 1;
                        int x1 = i - 1, x2 = j + 1;
                        int e = 0;
                        boolean e2 = true;
                        for (int i1 = Math.min(i - 1, npo - 1 - y2); i1 >= 0; i1--) {
                            if(Na.A[Na.dor][y1][y2] == null){
                                e2 = false;
                                break;
                            }
                            if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                x1 = y1;
                                x2 = y2;
                                e = 1;
                                break;
                            }
                            y1--;
                            y2++;
                        }
                        if (e == 1&& e2) {
                            for (int i1 = x2 - j - 1; i1 >= 0; i1--) {
                                Na.A[Na.dor][x1 + i1][x2 - i1] = new OthelloDisk(blackPlayer);
                            }
                        }
                    }
                }
            } if (i >= 2 && j >= 2) {  // bala_chap
                if(Na.A[Na.dor][i - 1][j - 1] != null) {
                    if (Na.A[Na.dor][i - 1][j - 1].isBlack() != blackPlayer) {
                        int y1 = i - 1, y2 = j - 1;
                        int x1 = i - 1, x2 = j - 1;
                        int e = 0;
                        boolean e2 = true;
                        for (int i1 = Math.min(y1, y2); i1 >= 0; i1--) {
                            if(Na.A[Na.dor][y1][y2] == null){
                                e2 = false;
                                break;
                            }
                            if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                x1 = y1;
                                x2 = y2;
                                e = 1;
                                break;
                            }
                            y1--;
                            y2--;
                        }
                        if (e == 1 && e2) {
                            for (int i1 = (i-1) - x1; i1 >= 0; i1--) {
                                Na.A[Na.dor][x1 + i1][x2 + i1] = new OthelloDisk(blackPlayer);
                            }
                        }
                        //Na.A[Na.dor][x1][x2].setR(blackPlayer);
                    }
                }
            } if (i <= npo - 3 && j <= npo - 3) {  // paeen_rast
                if(Na.A[Na.dor][i + 1][j + 1] != null) {
                    if (Na.A[Na.dor][i + 1][j + 1].isBlack() != blackPlayer) {
                        int y1 = i + 1, y2 = j + 1;
                        int e = 0;
                        int x1 = i + 1, x2 = j + 1;
                        boolean e2 = true;
                        for (int i1 = Math.min(npo - 1 - y1, npo - 1 - y2); i1 >= 0; i1--) {
                            if(Na.A[Na.dor][y1][y2] == null){
                                e2 = false;
                                break;
                            }
                            if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                x1 = y1;
                                x2 = y2;
                                e = 1;
                                break;
                            }
                            y1++;
                            y2++;
                        }
                        if (e == 1 && e2) {
                            for (int i1 = x2 - j - 1; i1 >= 0; i1--) {
                                Na.A[Na.dor][x1 - i1][x2 - i1] = new OthelloDisk(blackPlayer);
                            }
                        }
                    }
                }
            } if (i <= npo - 3 && j >= 2) {  // paeen_chap
                if(Na.A[Na.dor][i + 1][j - 1] != null) {
                    if (Na.A[Na.dor][i + 1][j - 1].isBlack() != blackPlayer) {
                        int y1 = i + 1, y2 = j - 1;
                        int x1 = i + 1, x2 = j - 1;
                        int e = 0;
                        boolean e2 = true;
                        for (int i1 = Math.min(y2, npo - 1 - y1); i1 >= 0; i1--) {
                            if(Na.A[Na.dor][y1][y2] == null){
                                e2 = false;
                                break;
                            }
                            if (Na.A[Na.dor][y1][y2].isBlack() == blackPlayer) {
                                x1 = y1;
                                x2 = y2;
                                e = 1;
                                break;
                            }
                            y1++;
                            y2--;
                        }
                        if (e == 1 && e2) {
                            for (int i1 = -x2 + (j - 1); i1 >= 0; i1--) {
                                Na.A[Na.dor][x1 - i1][x2 + i1] = new OthelloDisk(blackPlayer);
                            }
                        }
                    }
                }
            }
            if(blackPlayer) {
                Na.A[Na.dor][i][j] = new OthelloDisk(true);
            }
            else{
                Na.A[Na.dor][i][j] = new OthelloDisk(false);
            }
            if(shomaresh() == 0){
                getResultOfGame();
            }
            if(Valid(!blackPlayer) == false){
                for(int i1 = 0;i1 < npo;i1++){
                    for(int i2 = 0;i2 < npo;i2++){
                        if(Na.A[Na.dor][i1][i2] != null) {
                            Na.A[Na.dor + 1][i1][i2] = new OthelloDisk(Na.A[Na.dor][i1][i2].isBlack());
                        }
                    }
                }
                Na.Q[Na.dor] = 1;
                Na.dor += 1;
                sag += 1;
            }
        }
        else{
            if(Na.Y[sag] != blackPlayer) {


                if (Valid(true) == false && Valid(false) == false) {
                    getResultOfGame();
                } else {
//                if(blackPlayer) {
//                    //Na.dor += 1;
//                    if (Valid(false) == false) {
//                    } else {
//                        if (Valid(true) == false) {
//                        }
//                    }
//                    //Na.dor += 1;
//                }
                    for (int i1 = 0; i1 < npo; i1++) {
                        for (int i2 = 0; i2 < npo; i2++) {
                            if (Na.A[Na.dor][i1][i2] != null) {
                                Na.A[Na.dor + 1][i1][i2] = new OthelloDisk(Na.A[Na.dor][i1][i2].isBlack());
                            }
                        }
                    }
                    Na.dor += 1;
                }
            }
        }

    }

    public void undo() {
        if(Na.dor != 0) {
            Na = Na.getPervBoard();
        }

    }
    public int shomaresh(){
        int l1 = 0;
        for(int i1 = 0;i1 < npo;i1++){
            for(int i2 = 0;i2 < npo;i2++){
                if(this.Na.A[Na.dor][i1][i2] == null){
                    l1 += 1;
                }
            }
        }
        return l1;
    }
    public String getResultOfGame() {
        this.p1 = Valid(true);
        this.p2 = Valid(false);
        if((shomaresh() == 0) || ((p1 == false)  && (p2 == false))){
            int j2 = 0 , j1 = 0;
            for(int i1 = 0;i1 < npo;i1++){
                for(int i2 = 0;i2 < npo;i2++){
                    if(Na.A[Na.dor][i1][i2] != null) {
                        if (this.Na.A[Na.dor][i1][i2].isBlack() == true) {
                            j1 += 1;
                        }

                        if ((this.Na.A[Na.dor][i1][i2].isBlack() == false)) {
                            j2 += 1;
                        }
                    }
                }
            }
            this.payan = true;
            if(j1 == j2){
                return "draw";//Draw
            }
            if(j1 > j2){
                return player1.getName();
            }
            if(j1 < j2){
                return player2.getName();
            }
        }
        return "game still running";
    }

    public OthelloBoard getBoard() {
        return Na;
    }


    public OthelloPlayer getPlayer1() {
        return player1;
    }

    public OthelloPlayer getPlayer2() {
        return player2;
    }
}


