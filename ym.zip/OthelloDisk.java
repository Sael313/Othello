public class OthelloDisk {
    boolean r;
    public OthelloDisk(boolean t){
        this.r = t;
    }
    public boolean isBlack() {
        return r;
    }

    public void setR(boolean r) {
        this.r = r;
    }
}