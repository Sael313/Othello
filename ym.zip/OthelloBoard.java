import java.util.ArrayList;

public class OthelloBoard {
    int[] Q;
    boolean [] Y;
    OthelloDisk[][][] A;
    //boolean[][] B;
    int c;
    int dor;
    //OthelloBoard Taghir;

    public OthelloBoard(int p){
        c = p;
        A = new OthelloDisk[10000][p][p];
        A[0][p/2-1][p/2-1] = new OthelloDisk(false);
        A[0][p/2][p/2] = new OthelloDisk(false);
        A[0][p/2-1][p/2] = new OthelloDisk(true);
        A[0][p/2][p/2-1] = new OthelloDisk(true);

        this.dor = 0;
        Q = new int[10000];
        Q[0] = 0;
        Y = new boolean[10000];

    }
    @Override
    public String toString() {
        String e = "";
        for(int i1 = 0;i1 < c; i1++){
            for(int i2 = 0;i2 < c ;i2++){
                if(A[this.dor][i1][i2] == null){
                    e += '*';
                }
                else {
                    if (A[this.dor][i1][i2].isBlack() == false) {
                        e += 'W';
                    } else if ((A[this.dor][i1][i2]).isBlack() == true) {
                        e += 'B';
                    }
                }
                if(i2 != c-1){
                    e += ' ';
                }

            }
            if(i1 != c-1){
                e += '\n';
            }
        }
        return e;
    }
    public OthelloBoard getPervBoard() {
        if(this.dor <= 0 || (this.dor - 1 - Q[dor - 1]) < 0){
            return null;
        }
        else {
            OthelloBoard j = new OthelloBoard(c);
            j.dor = this.dor - 1 - Q[dor - 1];
            for (int i0 = 0; i0 < this.dor - Q[dor - 1]; i0++) {
                for (int i1 = 0; i1 < c; i1++) {
                    for (int i2 = 0; i2 < c; i2++) {
                        if (A[i0][i1][i2] != null) {
                            j.A[i0][i1][i2] = new OthelloDisk(true);

                            j.A[i0][i1][i2].setR(A[i0][i1][i2].isBlack());
                        }

                    }
                }
            }
            for(int i1 = 0;i1 < 1000;i1++){
                j.Q[i1] = Q[i1];
            }
            return j;
        }
    }

    public boolean isBlackPlayerToMove() {
        if(this.dor%2 == 0){
            return true;
        }
        else{
            return false;
        }
    }

    public OthelloDisk[][] getDisks() {
        OthelloDisk[][] u = new OthelloDisk[c][c];
        for(int i1 = 0;i1 < c;i1++){
            for(int i2 = 0;i2 < c;i2++){
                u[i1][i2] = A[this.dor][i1][i2] ;
            }
        }
        return u;
    }

    public void setDor(int y){
        this.dor = y;
    }
}



